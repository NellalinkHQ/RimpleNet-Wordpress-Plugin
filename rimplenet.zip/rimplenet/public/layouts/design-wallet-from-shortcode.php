<?php
//Included from shortcode in includes/class-wallets.php
//use case [rimplenet-wallet action="view_balance" user_id="1"]
 global $current_user;
 wp_get_current_user();

$atts = shortcode_atts( array(

    'action' => 'empty',
    'user_id' => $current_user->ID,
    'wallet_id' => 'woocommerce_base_cur',

), $atts );


$action = $atts['action'];
$user_id = $atts['user_id'];
$wallet_id = $atts['wallet_id'];

$wallet_obj = new Rimplenet_Wallets();
$all_wallets = $wallet_obj->getWallets();

if($action=='withdraw'){
    
    if(wp_verify_nonce($_POST['rimplenet_wallet_withdrawal_nonce'], 'rimplenet_wallet_withdrawal_nonce')){

		$wallet_id_submitted = $_POST["rimplenet_withdrawal_wallet"];
		$rimplenet_amount_to_withdraw_submitted  = $_POST["rimplenet_amount_to_withdraw"];
		$rimplenet_withdrawal_destination_submitted  = $_POST["rimplenet_withdrawal_destination"];
		$rimplenet_withdrawal_note_submitted  = $_POST["rimplenet_withdrawal_note"];
		
		$note = ' WITHDRAWAL - '.$rimplenet_withdrawal_note_submitted;
		$user_id = $current_user->ID;
		
		
		do_action('rimplenet_withdrawal_form_post', $current_user, $wallet_id_submitted, $rimplenet_amount_to_withdraw_submitted, $rimplenet_withdrawal_destination_submitted,$note );
		
		$wdr_info = $this->withdraw_wallet_bal($user_id, $rimplenet_amount_to_withdraw_submitted, $wallet_id_submitted, $rimplenet_withdrawal_destination_submitted, $note);
		
		if($wdr_info>1){
		    $success_message = 'Withdrawal Request Successful';
		    do_action('rimplenet_withdrawal_request_submitted_success', $wdr_info, $current_user, $wallet_id_submitted, $rimplenet_amount_to_withdraw_submitted, $rimplenet_withdrawal_destination_submitted,$note );
		
		}
		else{
		    
		    $error_message = $wdr_info;
		    do_action('rimplenet_withdrawal_request_submitted_failed', $wdr_info, $current_user, $wallet_id_submitted, $rimplenet_amount_to_withdraw_submitted, $rimplenet_withdrawal_destination_submitted,$note );
		
		}
		
		
		
       }
    ?>
   
  <div class="rimplenet-mt"> 
  
 

<center>
<div class="card">
<div class="card-header card-header-primary">
 Withdrawal
</div>
<div class="card-body">
 <br>
						<?php

                           if (!empty($success_message)) {
                         
                        ?>

                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <strong> SUCCESS: </strong> <?php echo $success_message; ?>
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <?php
                          }
    

                     ?>

					<?php

                           if (!empty($error_message)) {
                         
                        ?>

                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                          <strong> ERROR: </strong> <?php echo $error_message; ?>
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <?php
                          }
    

                     ?>

      <br>
 <form action="" method="post">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="rimplenet_withdrawal_wallet">Select Wallet</label>
      <select name="rimplenet_withdrawal_wallet" id="rimplenet_withdrawal_wallet" class="form-control" required>
         <?php
         
         if($wallet_id=='all'){
            
            foreach($all_wallets as $wallet){
              $wallet_id = $wallet['wallet_id'];
              if($wallet['include_in_withdrawal_form']=='yes'){
             
              ?>
                <option value="<?php echo $wallet_id; ?>" > <?php echo $wallet['name']; ?></option> 
            <?php
               }
             }
             
             
         }
         else{
             ?>
            <option value="<?php echo $wallet_id; ?>" selected> <?php echo $all_wallets[$wallet_id]['name']; ?></option> 
        <?php
         }
         ?>
      </select>
    </div>
    <div class="form-group col-md-6">
      <label for="rimplenet_amount_to_withdraw"> Amount to Withdraw</label>
      <input type="text" class="form-control" name="rimplenet_amount_to_withdraw" id="rimplenet_amount_to_withdraw" placeholder="e.g 1000 , no space, comma, currency sign or special character" required>
    </div>
  </div>
 
  <?php 
  do_action('rimplenet_withdrawal_form_before_withdrawal_destination');  
  $placeholder_text = apply_filters( 'rimplenet_withdrawal_field_placeholder', 'Type in your Bank Account Details', $wallet_id);
  ?> 
  <div class="form-row rimplenet_withdrawal_destination">
    <div class="form-group col-md-12">
    <label for="rimplenet_withdrawal_destination">Withdrawal Destination</label>
    <textarea class="form-control" name="rimplenet_withdrawal_destination" id="rimplenet_withdrawal_destination" rows="3" placeholder="<?php echo $placeholder_text; ?>"></textarea>
    </div>
  </div>
  <?php do_action('rimplenet_withdrawal_form_after_withdrawal_destination');  ?>
  
  <?php do_action('rimplenet_withdrawal_form_before_withdrawal_note');  ?>
  <div class="form-row rimplenet_withdrawal_note">
    <div class="form-group col-md-12">
    <label for="rimplenet_withdrawal_note">Withdrawal Note (optional) </label>
    <textarea class="form-control" name="rimplenet_withdrawal_note" id="rimplenet_withdrawal_note" rows="3" placeholder="Leave withdrawal note here"></textarea>
    </div>
  </div>
  <?php do_action('rimplenet_withdrawal_form_after_withdrawal_note');  ?>
  
	<?php wp_nonce_field( 'rimplenet_wallet_withdrawal_nonce', 'rimplenet_wallet_withdrawal_nonce' ); ?>
  <button type="submit" class="btn btn-primary">WITHDRAW</button>
</form>
</div>
</div>
</center>  

    
<?php
 }
elseif($action=='view_balance_history'){
    ?>
   
  <div class="rimplenetmlm-mt"> 
    <div class="row">
	 	<div class="col-md-12"> 

	 
			<?php
	      	   $txn_loop = new WP_Query(
                             array(  
                               'post_type' => 'rimplenettransaction', 
                               'post_status' => 'any',
                               'author' => $user_id ,
                               'posts_per_page' => -1,
                               'tax_query' => array(
                                   'relation' => 'OR',
                                   array(
                                    'taxonomy' => 'rimplenettransaction_type',
                                    'field'    => 'name',
                                    'terms'    => array( 'CREDIT' ),
                                  ),
                                  array(
                                    'taxonomy' => 'rimplenettransaction_type',
                                    'field'    => 'name',
                                    'terms'    => array( 'DEBIT' ),
                                        ),
                                       ),
                                    )
                              );
                              
                    if( $txn_loop->have_posts() ){
                    ?>
				     
				     <table class="table table-responsive-md">
				      <thead class="thead-dark">
				        <tr>
				          <th scope="col">ID</th>
				          <th scope="col">Date</th>
				          <th scope="col">Amount</th>
				          <th scope="col">Type</th>
				          <th scope="col">Note</th>
          				  <th scope="col"  style="display:none;">Action</th>

				        </tr>
				      </thead>
					      <tbody>
                <?php
                            
                    while( $txn_loop->have_posts() ){
                        $txn_loop->the_post();
                        $txn_id = get_the_ID(); 
                        $status = get_post_status();
                        
                        $date_time = get_the_date('D, M j, Y', $txn_id).'<br>'.get_the_date('g:i A', $txn_id);
                        $wallet_id = get_post_meta($txn_id, 'currency', true);

                        $all_rimplenet_wallets = $bal = $wallet_obj->getWallets();
                        
                        $wallet_symbol = $all_rimplenet_wallets[$wallet_id]['symbol'];
                        $wallet_decimal = $all_rimplenet_wallets[$wallet_id]['decimal'];
                        
                        
                        $amount = get_post_meta($txn_id, 'amount', true);
                        $txn_type = get_post_meta($txn_id, 'txn_type', true);
                        
                        
                        if($txn_type=="CREDIT"){
                        $amount_formatted_disp = '<font color="green">+'.$wallet_symbol.number_format($amount,$wallet_decimal).'</font>';
                        }
                        elseif($txn_type=="DEBIT"){
                            $amount_formatted_disp = '<font color="red">-'.$wallet_symbol.number_format($amount,$wallet_decimal).'</font>';
                        }
                        
                        $amount_formatted_disp = apply_filters("rimplenet_history_amount_formatted", $amount_formatted_disp,$txn_id, $txn_type, $amount, $amount_formatted_disp);
                        
                        $note = get_post_meta($txn_id, 'note', true);

   						$view_txn_nonce = wp_create_nonce('view_txn_nonce');
                        //$txn_view_url = add_query_arg( array( 'txn_id'=>$txn_id,'view_txn_nonce'=>$view_txn_nonce), home_url(add_query_arg(array(),$wp->request)) );



                    ?>

				        <tr>
				          <th scope="row"> #<?php echo $txn_id ?></th>
				          <td> <?php echo $date_time ?></th>
				          <td> <?php echo $amount_formatted_disp; ?> </td>
				          <td> <?php echo $txn_type; ?> </td>
				          <td ><?php echo $note; ?></td>
				          <td  style="display:none;">
				          	<a type="submit" name="deposit" href="<?php echo $txn_view_url; ?>" class="btn btn-success btn-sm" style="margin: 2px;"> View Txn </a>
				          </td>
				        </tr>

				        <?php

				          }
				         ?>
				         
				         
					      </tbody>
				      </table>
				         
				        <?php

				         }
				         else{
				         	echo "<center>No Transaction found for this request</center>";
				         }

                        wp_reset_postdata();

				        ?>


         </div>
	 	</div>
	   </div>
    
<?php
 }

elseif($action=='view_balance'){
    
    
    //$wallet_obj->add_user_immature_funds_to_wallet($user_id, -10,$wallet_id, 'Testing here');
     
    $bal = $wallet_obj->get_total_wallet_bal_disp_formatted($user_id, $wallet_id );

    echo $bal;
}
else{
  echo __('You did not specify a valid wallet action in shortcode e.g [rimplenet-wallet action="view_balance"] has a valid action which is view balance', 'rimplenet-text-domain'); 
}




?>