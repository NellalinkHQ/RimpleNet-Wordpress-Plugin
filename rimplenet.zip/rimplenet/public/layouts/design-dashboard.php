<?php 
//Included from shortcode in public/class-bnvb-mlm-public.php
//use case [bnvb-dashboard top="Menu-top-menu" left="Menu-LeftMLM" right="Menu-RightMLM" default-content="2"]
 global $current_user;
 wp_get_current_user();

$atts = shortcode_atts( array(

    'top' => 'empty',
    'left' => 'empty',
    'right' => 'empty',
    'default-content' => '[bnvb-mlm-my-stats]',

), $atts );


$top = $atts['top'];
$left = $atts['left'];
$right = $atts['right'];


if (is_numeric($_GET['bnvb-view-post'])) {

  $custom_post = get_post($_GET['bnvb-view-post']);
  $content =  apply_filters('the_content', $custom_post->post_content);
  
  $active_menu_post_id = $_GET['bnvb-view-post'];

}
elseif(is_numeric($atts['default-content'])) {

  $custom_post = get_post($atts['default-content']);
  $content =  apply_filters('the_content', $custom_post->post_content);
  
  $active_menu_post_id = $atts['default-content'];


}
else{
	$content = $atts['default-content'];
}




$topName = (getBnvBMenu($top) ? getBnvBMenu($top) : getBnvBWidget($top));
$leftName = (getBnvBMenu($left) ? getBnvBMenu($left) : getBnvBWidget($left));
$rightName = (getBnvBMenu($right) ? getBnvBMenu($right) : getBnvBWidget($right));


if ($top!='empty' && getBnvBDashboardSuppliedDesign($top)==false) {
	echo '<div class="alert alert-danger">
         <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID FORMAT SUPPLIED FOR TOP VIA SHORTCODE</b> - <i>'.$topName.'</i> prepend by menu, choose <b>menu</b> either by name, id or location e.g <b>  top="menu my custom menu name"  or top="menu-55" or top="menu-primary"</b>
         </div>
        </div>';
}

elseif (getSuppliedDesign($top)=='menu') {


	$topMenu = wp_get_nav_menu_items($topName);
	if ($topMenu!=false) {
	
	

?>









<div class="bnvbmlm-mt">
    
    <div class="se-pre-con"></div>
      <!-- Simulate Active Page
      <li class="nav-item">
        <a class="nav-link active" href="#settings" data-toggle="tab">
          <i class="material-icons">build</i>
          Settings
        <div class="ripple-container"></div></a>
      </li>
      -->
      
          <?php
        	   //var_dump($topMenu);
        	   foreach ($topMenu as $key => $menu) {

              if (get_post_meta( $menu->ID, '_bnvb_menu_meta',true)) {
                $icon_name = get_post_meta( $menu->ID, '_bnvb_menu_meta',true);
                $icon_disp = '<i class="material-icons">'.$icon_name.'</i>';
              }
              else{
                $icon_disp = '';
              }


              $post_id = $menu->object_id;
        	 	
        	 ?>

            <li class="nav-item">
              <a class="nav-link" href="?bnvb-view-post=<?php echo $post_id; ?>">

                <?php echo  $icon_disp; ?>
                <?php echo $menu->title; ?>

              <div class="ripple-container"></div></a>
            </li>

      	  <?php
      	  	 
      	  	 }

      	   ?>
              
      </ul>
    </div>
  </div>
</div>
      

<?php

}

 else{
	echo '<div class="alert alert-danger">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID MENU SUPPLIED FOR TOP VIA SHORTCODE</b> - <em>'.$topName.'</em> is not a valid menu parameter, choose menu either by name, id or location e.g <b>  top="menu my custom menu name"  or top="menu-55" or top="menu-primary"</b>
         </div>
       </div>';
	}

}

?>






<!-- Dashboard Design Start Here -->

<div class="se-pre-con"></div>
 <div class="wrapper">

<?php
 //Start Left
if ($left!='empty' && getSuppliedDesign($left)==false) {
  echo '<div class="alert alert-danger">
         <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID FORMAT SUPPLIED FOR LEFT VIA SHORTCODE</b> - <i>'.$leftName.'</i> prepend by menu, choose <b>menu</b> either by name, id or location e.g <b>  left="menu my custom menu name"  or left="menu-55" or left="menu-primary"</b>
         </div>
        </div>';
}

elseif (getSuppliedDesign($left)=='menu') {


  $leftMenu = wp_get_nav_menu_items($leftName);
  if ($leftMenu!=false) {
  
  

?>


<!-- Left Sidebar Holder -->
<nav id="sidebar" class="">
<div class="sidebar-header">
    <h6>
        <a href="javascript:void(0)">DASHBOARD</a>
    </h6>
    <span>---</span>
</div>
<div class="profile-bg"></div>
 <ul class="list-unstyled components">
        
  <?php
   //var_dump($leftMenu);
   
   
    $menu_parent_ids = array_column($leftMenu, 'menu_item_parent');
    $menu_parent_ids_count =  array_count_values($menu_parent_ids);
   foreach ($leftMenu as $key => $menu) {
       
     //$menu_item_target = get_post_meta( $menu->ID, '_menu_item_target',true);
     $post_id = $menu->object_id;
    
      if (get_post_meta( $menu->ID, '_bnvb_menu_meta',true)) {
        $icon_name = get_post_meta( $menu->ID, '_bnvb_menu_meta',true);
        $icon_disp = '<span class="material-icons">'.$icon_name.'</span>';
      }
      else{
        $icon_disp = '';
      }

      if($post_id==$active_menu_post_id){
          $active_menu_disp = 'active';
      }
      else{
        $active_menu_disp = '';
      }
     
     if($menu->target=='_blank'){
         
       $menu_item_link = $menu->url;
     }
     else{
        
        $menu_item_link =  '?bnvb-view-post='.$post_id;
     }
     
     //echo var_dump($menu);
      
      
      if ($menu->menu_item_parent == 0) {//has no parent
        $child_counter = $menu_parent_ids_count[$menu->ID];
        if($child_counter>1){ //if has children, open tag <li> and <a with class dropdown ot be closed in COUNTER REDUCTION FXN
             ?>
             
            <li class="<?php echo $active_menu_disp ?>">
                <a href="#Dropdown<?php echo $menu->ID; ?>" data-toggle="collapse" aria-expanded="false"  target="<?php echo $menu->target; ?>">
                               
                   <?php echo  $icon_disp; ?> <?php echo $menu->title; ?> 
                    <i class="fas fa-angle-down fa-pull-right"></i>
                </a>
                <ul class="collapse list-unstyled" id="Dropdown<?php echo $menu->ID; ?>" >
             <?php
                }
                else{
                 ?>
                <li class="<?php echo $active_menu_disp ?>">
                    <a href="<?php echo $menu_item_link; ?>" target="<?php echo $menu->target; ?>">
                        
                       <?php echo  $icon_disp; ?> <?php echo $menu->title; ?> 
                    </a>
                </li>
            
                 <?php    
                }
      }
      else{ //When it has parent
      
   ?>
       
      <li class="<?php echo $active_menu_disp ?>">
            <a href="<?php echo $menu_item_link; ?>" target="<?php echo $menu->target; ?>">
               
               <?php echo  $icon_disp; ?> <?php echo $menu->title; ?>  
               
            </a>
        </li>

   
  <?php
  
          $child_counter--;//reduce remaining children - COUNTER REDUCTION FXN 
          if($child_counter==0){
              echo ' </ul>
                </li>';
              $child_counter = 'not_yet';
          }
      }
     
     }

   ?>
              
  </ul>
</nav>
      

<?php

}

 else{
  echo '<div class="alert alert-danger">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID MENU SUPPLIED FOR LEFT VIA SHORTCODE</b> - <em>'.$leftName.'</em> is not a valid menu parameter, choose menu either by name, id or location e.g <b>  left="menu my custom menu name"  or left="menu-55" or left="menu-primary"</b>
         </div>
       </div>';
  }

}

?>



 <!-- Page Content Holder -->
        <div id="content">
            <!-- top-bar -->
           
            <nav class="navbar navbar-default mb-xl-5 mb-4">
                <div class="container-fluid">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="btn btn-info navbar-btn">
                            <i class="fas fa-bars"></i>
                        </button>
                        
                    </div>
                    <div>
                        <h4 class="tittle-w3-agileits mb-4"> Welcome  <?php echo $current_user->user_login; ?>, </h4>
                    </div>
                    
                 
                </div>
            </nav>            
            <!--// top-bar -->
           <div class="outer-w3-agile col-xl mt-3">
                <?php echo $content; ?> 
            </div>
            
            <!-- Copyright -->
            <div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center">
                 <p> © <?php echo date('Y').' '.get_bloginfo('name'); ?>. All Rights Reserved  </p>
            </div>
            <!--// Copyright -->
        </div>

</div><!-- Wrapper End -->
<!-- Dashboard Design Start Here -->
















<div class="bnvbmlm-mt" style="display:none">
    
    
    
    
 <div class="card card-nav-tabs">

<?php 
//Included from shortcode in class-sms.php
//use case [bnvb-mlm-dashboard top="Menu-top-menu" left="Menu-LeftMLM" right="Menu-RightMLM" default-content="2"]
 global $current_user;
 wp_get_current_user();

$atts = shortcode_atts( array(

    'top' => 'empty',
    'left' => 'empty',
    'right' => 'empty',
    'default-content' => '[bnvb-mlm-my-stats]',

), $atts );


$top = $atts['top'];
$left = $atts['left'];
$right = $atts['right'];


if (is_numeric($_GET['bnvb-view-post'])) {

  $custom_post = get_post($_GET['bnvb-view-post']);
  $content =  apply_filters('the_content', $custom_post->post_content);

}
elseif(is_numeric($atts['default-content'])) {

  $custom_post = get_post($atts['default-content']);
  $content =  apply_filters('the_content', $custom_post->post_content);


}
else{
	$content = $atts['default-content'];
}




$topName = (getMenu($top) ? getMenu($top) : getWidget($top));
$leftName = (getMenu($left) ? getMenu($left) : getWidget($left));
$rightName = (getMenu($right) ? getMenu($right) : getWidget($right));


if ($top!='empty' && getSuppliedDesign($top)==false) {
	echo '<div class="alert alert-danger">
         <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID FORMAT SUPPLIED FOR TOP VIA SHORTCODE</b> - <i>'.$topName.'</i> prepend by menu, choose <b>menu</b> either by name, id or location e.g <b>  top="menu my custom menu name"  or top="menu-55" or top="menu-primary"</b>
         </div>
        </div>';
}

elseif (getSuppliedDesign($top)=='menu') {


	$topMenu = wp_get_nav_menu_items($topName);
	if ($topMenu!=false) {
	
	

?>








<!--
<div class="">
  
 <nav role="navigation-demo" class="card-header card-header-primary navbar navbar-inverse navbar-expand-lg bg-dark">
            <div class="container">
               #Brand and toggle get grouped for better mobile display 
              <div class="navbar-translate">
                <a class="navbar-brand" href="#0">Navbar with notification<div class="ripple-container"></div></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="navbar-toggler-icon"></span>
                  <span class="navbar-toggler-icon"></span>
                  <span class="navbar-toggler-icon"></span>
                </button>
              </div>
               #Collect the nav links, forms, and other content for toggling
              <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                  <li class="active nav-item">
                    <a href="javascript:;" class="nav-link">
                      <i class="material-icons">explore</i>
                      Discover
                    <div class="ripple-container"></div></a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:;" class="nav-link">
                      Wishlist
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:;" class="btn btn-rose btn-raised btn-fab btn-round" data-toggle="dropdown">
                      <i class="material-icons">email</i>
                    </a>
                  </li>
                  <li class="dropdown nav-item">
                    <a href="javascript:;" class="profile-photo dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false">
                      <div class="profile-photo-small">
                        <img src="https://demos.creative-tim.com/material-kit-pro/assets/img/tim-logo.png" alt="Circle Image" class="rounded-circle img-fluid">
                      </div>
                    <div class="ripple-container"></div></a>
                    <div class="dropdown-menu dropdown-menu-right">
                      <h6 class="dropdown-header">Dropdown header</h6>
                      <a href="javascript:;" class="dropdown-item">Me</a>
                      <a href="javascript:;" class="dropdown-item">Settings and other stuff</a>
                      <a href="javascript:;" class="dropdown-item">Sign out</a>
                    </div>
                  </li>
                </ul>
              </div># /.navbar-collapse 
            </div> # /.container
          </nav>
</div>
-->











<div class="card-header card-header-primary">
    <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
 <div class="nav-tabs-navigation">
  <div class="nav-tabs-wrapper">
    <ul class="nav nav-tabs" data-tabs="tabs">
      
      <!-- Simulate Active Page
      <li class="nav-item">
        <a class="nav-link active" href="#settings" data-toggle="tab">
          <i class="material-icons">build</i>
          Settings
        <div class="ripple-container"></div></a>
      </li>
    -->
      
          <?php
        	   //var_dump($topMenu);
        	   foreach ($topMenu as $key => $menu) {

              if (get_post_meta( $menu->ID, '_bnvb_menu_meta',true)) {
                $icon_name = get_post_meta( $menu->ID, '_bnvb_menu_meta',true);
                $icon_disp = '<i class="material-icons">'.$icon_name.'</i>';
              }
              else{
                $icon_disp = '';
              }


              $post_id = $menu->object_id;
        	 	
        	 ?>

            <li class="nav-item">
              <a class="nav-link" href="?bnvb-view-post=<?php echo $post_id; ?>">

                <?php echo  $icon_disp; ?>
                <?php echo $menu->title; ?>

              <div class="ripple-container"></div></a>
            </li>

      	  <?php
      	  	 
      	  	 }

      	   ?>
              
      </ul>
    </div>
  </div>
</div>
      

<?php

}

 else{
	echo '<div class="alert alert-danger">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID MENU SUPPLIED FOR TOP VIA SHORTCODE</b> - <em>'.$topName.'</em> is not a valid menu parameter, choose menu either by name, id or location e.g <b>  top="menu my custom menu name"  or top="menu-55" or top="menu-primary"</b>
         </div>
       </div>';
	}

}

?>


<div class="row tab-space">

<?php
 //Start Left
if ($left!='empty' && getSuppliedDesign($left)==false) {
  echo '<div class="alert alert-danger">
         <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID FORMAT SUPPLIED FOR LEFT VIA SHORTCODE</b> - <i>'.$leftName.'</i> prepend by menu, choose <b>menu</b> either by name, id or location e.g <b>  left="menu my custom menu name"  or left="menu-55" or left="menu-primary"</b>
         </div>
        </div>';
}

elseif (getSuppliedDesign($left)=='menu') {


  $leftMenu = wp_get_nav_menu_items($leftName);
  if ($leftMenu!=false) {
  
  

?>

<div class="col-md-3">
    <ul class="nav nav-pills nav-pills-icons flex-column">
      <!--<li class="nav-item"><a class="nav-link active" href="#tab1" data-toggle="tab">Profile</a></li>
      -->
          <?php
           //var_dump($topMenu);
             foreach ($leftMenu as $key => $menu) {
              if (get_post_meta( $menu->ID, '_bnvb_menu_meta',true)) {
                $icon_name = get_post_meta( $menu->ID, '_bnvb_menu_meta',true);
                $icon_disp = '<i class="material-icons">'.$icon_name.'</i>';
              }
              else{
                $icon_disp = '';
              }

              $post_id = $menu->object_id;

            
           ?>
        

           <li class="nav-item">
            <a class="nav-link" href="?bnvb-view-post=<?php echo $post_id; ?>">
             
                <?php echo  $icon_disp; ?>
                <?php echo $menu->title; ?>

            </a>
           </li>

          <?php
             
             }

           ?>
              
  </ul>
</div>
      

<?php

}

 else{
  echo '<div class="alert alert-danger">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID MENU SUPPLIED FOR LEFT VIA SHORTCODE</b> - <em>'.$leftName.'</em> is not a valid menu parameter, choose menu either by name, id or location e.g <b>  left="menu my custom menu name"  or left="menu-55" or left="menu-primary"</b>
         </div>
       </div>';
  }

}

?>

<?php

if ($left!='empty' AND $right!='empty'){
  $middle_col = 'col-md-6';
}
elseif ($left!='empty' OR $right!='empty') {
  $middle_col = 'col-md-9';
}
else{
  $middle_col = 'col-md-12';
}


?>


<div class="<?php echo $middle_col; ?>">
    <div class="tab-content card-body">
      <div class="tab-pane active" id="tab1">
         <?php echo $content; ?> 
      </div>
    </div>
</div>


  

<?php
 //Start Right
if ($right!='empty' && getSuppliedDesign($right)==false) {
  echo '<div class="alert alert-danger">
         <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID FORMAT SUPPLIED FOR RIGHT VIA SHORTCODE</b> - <i>'.$rightName.'</i> prepend by menu, choose <b>menu</b> either by name, id or location e.g <b>  right="menu my custom menu name"  or right="menu-55" or right="menu-primary"</b>
         </div>
        </div>';
}

elseif (getSuppliedDesign($right)=='menu') {


  $rightMenu = wp_get_nav_menu_items($rightName);
  if ($rightMenu!=false) {
  
  

?>

<div class="col-md-3">
    <ul class="nav nav-pills nav-pills-icons flex-column">
      <!--<li class="nav-item"><a class="nav-link active" href="#tab1" data-toggle="tab">Profile</a></li>
      -->
          <?php
           //var_dump($topMenu);
             foreach ($rightMenu as $key => $menu) {
              if (get_post_meta( $menu->ID, '_bnvb_menu_meta',true)) {
                $icon_name = get_post_meta( $menu->ID, '_bnvb_menu_meta',true);
                $icon_disp = '<i class="material-icons">'.$icon_name.'</i>';
              }
              else{
                $icon_disp = '';
              }

              $post_id = $menu->object_id;
            
           ?>

           <li class="nav-item">
            <a class="nav-link" href="?bnvb-view-post=<?php echo $post_id; ?>">
             
                <?php echo  $icon_disp; ?>
                <?php echo $menu->title; ?>

            </a>
           </li>

          <?php
             
             }

           ?>
              
  </ul>
</div>
      

<?php

}

 else{
  echo '<div class="alert alert-danger">
        <div class="container">
          <div class="alert-icon">
            <i class="material-icons">error_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>INVALID MENU SUPPLIED FOR RIGHT VIA SHORTCODE</b> - <em>'.$rightName.'</em> is not a valid menu parameter, choose menu either by name, id or location e.g <b>  right="menu my custom menu name"  or right="menu-55" or right="menu-primary"</b>
         </div>
       </div>';
  }

}

?>

  </div><!-- Row End-->
 </div>
</div>


<?php




function getMenu($string=''){
	if (strtolower(substr($string, 0, 4))=='menu') {
	return substr($string, 5);
   }
   return false;
}

function getWidget($string=''){
	if (strtolower(substr($string, 0, 6))=='widget') {
	return substr($string, 7);
   }

   return false;
}


function getSuppliedDesign($string=''){

  if (strtolower(substr($string, 0, 4))=='menu') {
	 return 'menu';
   }

   elseif (strtolower(substr($string, 0, 6))=='widget') {
	return 'widget';
   }
   else{
   	return false;
   }

}



?>












    
<!-- Bootstrap Css -->
<?php $inc_dir = plugin_dir_url( dirname( __FILE__ )).'css/dashboard'; ?>
<link href="<?php echo $inc_dir;  ?>/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Bootstrap Css -->
<!-- Bars Css -->
<link rel="stylesheet" href="<?php echo $inc_dir; ?>/css/bar.css">
<!--// Bars Css -->
<!-- Calender Css -->
<link rel="stylesheet" type="text/css" href="<?php echo $inc_dir; ?>/css/pignose.calender.css" />
<!--// Calender Css -->
<!-- Common Css -->
<link href="<?php echo $inc_dir; ?>/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!--// Common Css -->
<!-- Nav Css -->
<link rel="stylesheet" href="<?php echo $inc_dir; ?>/css/style4.css">
<!--// Nav Css -->
<!-- widgets Css -->
<link href="<?php echo $inc_dir; ?>/css/widgets.css" rel="stylesheet">
<!-- widgets Css -->
<!-- Fontawesome Css -->
<link href="<?php echo $inc_dir; ?>/css/fontawesome-all.css" rel="stylesheet">
<!--// Fontawesome Css -->
<!--// Style-sheets -->



<!-- Required common Js -->
<?php $inc_dir = plugin_dir_url( dirname( __FILE__ )).'js/dashboard'; ?>

<script src='<?php echo $inc_dir; ?>/jquery-2.2.3.min.js'></script>
<!-- //Required common Js -->

<!-- loading-gif Js -->
<script src="<?php echo $inc_dir; ?>/modernizr.js"></script>
<script>
    //paste this code under head tag or in a seperate js file.
    // Wait for window load
    $(window).load(function () {
        // Animate loader off screen
        $(".se-pre-con").fadeOut("slow");;
    });
</script>
<!--// loading-gif Js -->

<!-- Sidebar-nav Js -->
<script>
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
        });
    });
</script>
<!--// Sidebar-nav Js -->

<!-- Graph -->
<script src="<?php echo $inc_dir; ?>/SimpleChart.js"></script>
<script>
    var graphdata4 = {
        linecolor: "Random",
        title: "Thursday",
        values: [{
                X: "6",
                Y: 300.00
            },
            {
                X: "7",
                Y: 101.98
            },
            {
                X: "8",
                Y: 140.00
            },
            {
                X: "9",
                Y: 340.00
            },
            {
                X: "10",
                Y: 470.25
            },
            {
                X: "11",
                Y: 180.56
            },
            {
                X: "12",
                Y: 680.57
            },
            {
                X: "13",
                Y: 740.00
            },
            {
                X: "14",
                Y: 800.89
            },
            {
                X: "15",
                Y: 420.57
            },
            {
                X: "16",
                Y: 980.24
            },
            {
                X: "17",
                Y: 1080.00
            },
            {
                X: "18",
                Y: 140.24
            },
            {
                X: "19",
                Y: 140.58
            },
            {
                X: "20",
                Y: 110.54
            },
            {
                X: "21",
                Y: 480.00
            },
            {
                X: "22",
                Y: 580.00
            },
            {
                X: "23",
                Y: 340.89
            },
            {
                X: "0",
                Y: 100.26
            },
            {
                X: "1",
                Y: 1480.89
            },
            {
                X: "2",
                Y: 1380.87
            },
            {
                X: "3",
                Y: 1640.00
            },
            {
                X: "4",
                Y: 1700.00
            }
        ]
    };
    $(function () {
        $("#Hybridgraph").SimpleChart({
            ChartType: "Hybrid",
            toolwidth: "50",
            toolheight: "25",
            axiscolor: "#E6E6E6",
            textcolor: "#6E6E6E",
            showlegends: false,
            data: [graphdata4],
            legendsize: "140",
            legendposition: 'bottom',
            xaxislabel: 'Hours',
            title: 'Weekly Profit',
            yaxislabel: 'Profit in $'
        });
    });
</script>
<!--// Graph -->
<!-- Bar-chart -->
<script src="<?php echo $inc_dir; ?>/rumcaJS.js"></script>
<script src="<?php echo $inc_dir; ?>/example.js"></script>
<!--// Bar-chart -->
<!-- Calender -->
<script src="<?php echo $inc_dir; ?>/moment.min.js"></script>
<script src="<?php echo $inc_dir; ?>/pignose.calender.js"></script>
<script>
    //<![CDATA[
    $(function () {
        $('.calender').pignoseCalender({
            select: function (date, obj) {
                obj.calender.parent().next().show().text('You selected ' +
                    (date[0] === null ? 'null' : date[0].format('YYYY-MM-DD')) +
                    '.');
            }
        });

        $('.multi-select-calender').pignoseCalender({
            multiple: true,
            select: function (date, obj) {
                obj.calender.parent().next().show().text('You selected ' +
                    (date[0] === null ? 'null' : date[0].format('YYYY-MM-DD')) +
                    '~' +
                    (date[1] === null ? 'null' : date[1].format('YYYY-MM-DD')) +
                    '.');
            }
        });
    });
    //]]>
</script>
<!--// Calender -->

<!-- profile-widget-dropdown js-->
<script src="<?php echo $inc_dir; ?>/script.js"></script>
<!--// profile-widget-dropdown js-->

<!-- Count-down -->
<script src="<?php echo $inc_dir; ?>/simplyCountdown.js"></script>
<link href="<?php echo $inc_dir; ?>/css/simplyCountdown.css" rel='stylesheet' type='text/css' />
<script>
    var d = new Date();
    simplyCountdown('simply-countdown-custom', {
        year: d.getFullYear(),
        month: d.getMonth() + 2,
        day: 25
    });
</script>
<!--// Count-down -->

<!-- pie-chart -->
<script src='<?php echo $inc_dir; ?>/amcharts.js'></script>
<script>
    var chart;
    var legend;

    var chartData = [{
            country: "Lithuania",
            value: 260
        },
        {
            country: "Ireland",
            value: 201
        },
        {
            country: "Germany",
            value: 65
        },
        {
            country: "Australia",
            value: 39
        },
        {
            country: "UK",
            value: 19
        },
        {
            country: "Latvia",
            value: 10
        }
    ];

    AmCharts.ready(function () {
        // PIE CHART
        chart = new AmCharts.AmPieChart();
        chart.dataProvider = chartData;
        chart.titleField = "country";
        chart.valueField = "value";
        chart.outlineColor = "";
        chart.outlineAlpha = 0.8;
        chart.outlineThickness = 2;
        // this makes the chart 3D
        chart.depth3D = 20;
        chart.angle = 30;

        // WRITE
        chart.write("chartdiv");
    });
</script>
<!--// pie-chart -->

<!-- dropdown nav -->
<script>
    $(document).ready(function () {
        $(".dropdown").hover(
            function () {
                $('.dropdown-menu', this).stop(true, true).slideDown("fast");
                $(this).toggleClass('open');
            },
            function () {
                $('.dropdown-menu', this).stop(true, true).slideUp("fast");
                $(this).toggleClass('open');
            }
        );
    });
</script>
<!-- //dropdown nav -->

<!-- Js for bootstrap working-->
<script src="<?php echo $inc_dir; ?>/bootstrap.min.js"></script>
<!-- //Js for bootstrap working -->