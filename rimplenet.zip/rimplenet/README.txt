=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://rimplenet.com/donate
Tags: ewallet, mlm, matrix, investments, invest, dashboard,
Requires at least: 3.0.1
Tested up to: 5.4.2
Stable tag: 0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Rimplenet is a Financial Technology (FinTech) Plugin for Wordpress with E-Wallet Functionality used to setup MLM, Matrix, Investments and Packages, and even dashboard on Wordpress. Using this Plugin is simple, install it, RIMPLENET will appear on your admin dashboard menu (with ability to create Ewallets, Matrix, Packages). Admin can auto credit or debit using rules or manually via the user edit page.

== Description ==


Rimplenet is a Financial Technology (FinTech) Plugin for Wordpress with E-Wallet Functionality used to setup MLM, Matrix, Investments and Packages, and even dashboard on Wordpress. Using this Plugin is simple, install it, RIMPLENET will appear on your admin dashboard menu (with ability to create Ewallets, Matrix, Packages). Admin can auto credit or debit using rules or manually via the user edit page


== Installation ==

***Download rimplenet.zip
1. Upload `rimplenet.zip` via ftp or cpanel upload to the folder `/wp-content/plugins/` directory of your wordpress website installation. OR Login to your wordpress admin dashboard and upload the .zip file
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What are Required to use this Plugin? =

 Install Wordpress, Install Woocommerce Plugin, then install Rimplenet

= How do I create matrix, packages and ewallets? =

Click Rimplenet on your wordpress admin backend, then click the menu you want to create either matrix, packages or ewallets. then Copy paste the shortcode in the page you want it to work

= How can I display Individuals User Credit=

Use shortcode [rimplenet-wallet action="view_balance" wallet_id="YOUR_CREATED_WALLET_ID_HERE"].


= How can I Credit User Wallet?=

Go to User -> Edit, scroll down, you will see fields to edit user Wallets.

= How do I restrict users that joins a particular matrix or packages=

The sweetest thing about our Plugin, We use rules, for example to allow a user to join PACKAGE-1 by buying a product (product 1). Then after earn earn 100USD.

The rules goes this way 

rules_before_package_entry == rimplenet_rules_check_woocomerce_product_purchase_status:PRODUCT_ID
rimplenet_rules_inside_package_and_linked_product_ordered

    rimplenet_rules_add_to_mature_wallet: 100, woocommerce_base_cur
    OR
    rimplenet_rules_add_to_mature_wallet: 100, WALLET_ID
    
    Rules is thoroughly explained at rimplenet.com/rules


== A brief Markdown Example ==

Ordered list:

1. Create Wallet
2. Create Matrix Tree by just inputing shortcode
3. Create Packages
4. Payment Integration Supported via Woocommerce (Meaning your LOCAL PAYMENT PROCESSOR is there)
