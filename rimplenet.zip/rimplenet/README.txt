=== RimpleNet E-Wallets, E-Banking | Investments Plugin | MLM | Matrix | Referral Manager | FinTech ===
Contributors: nellalink
Donate link: https://rimplenet.com/donate
Tags: wallet-creator, ewallet, e-wallet, ebanking, e-banking, mlm, matrix, matrix-tree, investment, investment-plugin, loan-plugin-maker, woocommerce-payment-processor-maker
Requires at least: 3.0.1
Tested up to: 5.5.1
Stable tag: 1.0.0
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Rimplenet is a Financial Technology (FinTech) Plugin for Wordpress with E-Wallet Functionality used to setup E-Banking, Loan- Requester App, MLM, Matrix, Investments and Packages. Using this Plugin is simple, install it, RIMPLENET will appear on your admin dashboard menu (with ability to create Ewallets, Matrix, Packages, and E-banking Rules). Admin can auto credit or debit using rules or manually via the user edit page. WALLETS can be use for making woocommerce payment. How to Use this Plugin: visit https://rimplenet.com/docs

== Description ==


Rimplenet is a Financial Technology (FinTech) Plugin for Wordpress with E-Wallet, E-Banking Functionality, it can be used to setup MLM, Matrix, Investments and Packages, and even dashboard on Wordpress. Using this Plugin is simple, install it, RIMPLENET will appear on your admin dashboard menu (with ability to create Ewallets, Matrix, Packages). Admin can auto credit or debit using rules or manually via the user edit page. WALLETS can be use for making woocommerce payment. How to Use this Plugin: visit https://rimplenet.com/docs


== Installation ==

***Download rimplenet.zip
1. Upload `rimplenet.zip` via ftp or cpanel upload to the folder `/wp-content/plugins/` directory of your wordpress website installation. OR Login to your wordpress admin dashboard and upload the .zip file
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What are Required to use this Plugin? =

 Install Wordpress, Install Woocommerce Plugin, then install Rimplenet

= How do I create matrix, packages and ewallets? =

Click Rimplenet on your wordpress admin backend, then click the menu you want to create either matrix, packages or ewallets. then Copy paste the shortcode in the page you want it to work

= How can I display Individuals User Credit=

Use shortcode [rimplenet-wallet action="view_balance" wallet_id="YOUR_CREATED_WALLET_ID_HERE"].


= How can I Credit User Wallet?=

Go to User -> Edit, scroll down, you will see fields to edit user Wallets.

= How do I restrict users that joins a particular matrix or packages=

The sweetest thing about our Plugin, We use rules, for example to allow a user to join PACKAGE-1 by buying a product (product 1). Then after earn earn 100USD.

The rules goes this way 

rules_before_package_entry == rimplenet_rules_check_woocomerce_product_purchase_status:PRODUCT_ID
rimplenet_rules_inside_package_and_linked_product_ordered

    rimplenet_rules_add_to_mature_wallet: 100, woocommerce_base_cur
    OR
    rimplenet_rules_add_to_mature_wallet: 100, WALLET_ID
    
    Rules is thoroughly explained at rimplenet.com/rules


= I have Setup Issues or other Questions not include =

Contact us via Phonecall or Live Chat or Via our Support forum, we answer as soon as possible in few minutes, visit our website at www.rimplenet.com and choose any contact channel suitable for you.

== Screenshots ==

1. Create Wallet from Admin Screen
2. Edit Wallet Balance from User Edit Screen
3. Display Withdrawal Form using shortcode
4. Create Package from Admin Screen
5. List Package using Shortcode
6. Create Matrix from Admin Screen
7. Display Matrix Tree with Shortcode
8. Simple Designed Wallet Balance and User Meta Dashboard using Shortcodes

== Changelog ==

= 1.0 =
* Launch of Rimplenet, Download, Use and Give us Feedback.


== Upgrade Notice ==

= 1.0 =
Launch of Rimplenet, Download, Use and Give us Feedback.

== A brief Markdown Example ==

1. Create Unlimited Wallet and display with their shortcode
2. Create MLM and Matrix Tree and display with their shortcode
3. Create Packages/Plans (package/plans are set by rules, visit How to Use this Plugin: visit https://rimplenet.com/docs to learn more)
***Wallets can be set up via rules so users recieve rewards in his /her wallets automatically (rewards can be set daily, weekly, monthly etc)
***Wallet can be used as Woocommerce Payment Processor, setup can be done via Woocommerce Payments, you can use this plugin to create your woocommerce payment processor with your name
4. Users can fund wallet using bank, or any Payment Integration Supported via Woocommerce (Meaning your LOCAL PAYMENT PROCESSOR is probably there)
5. Wallet Withdrawal Page Supported by use of Shortcode
