<?php

$WALLET_CAT_NAME = 'RIMPLENET WALLETS';


if(isset( $_POST['rimplenet_wallet_submitted'] ) || wp_verify_nonce( $_POST['rimplenet_wallet_settings_nonce_field'], 'rimplenet_wallet_settings_nonce_field' ) )  {

$rimplenet_wallet_name = sanitize_text_field( $_POST['rimplenet_wallet_name'] );
$rimplenet_wallet_desc = sanitize_text_field( $_POST['rimplenet_wallet_desc'] );
$rimplenet_wallet_decimal = sanitize_text_field( $_POST['rimplenet_wallet_decimal'] );
$rimplenet_wallet_symbol = sanitize_text_field( $_POST['rimplenet_wallet_symbol'] );
$include_in_withdrawal_form = sanitize_text_field( $_POST['include_in_withdrawal_form'] );
$include_in_woocommerce_currency_list = sanitize_text_field( $_POST['include_in_woocommerce_currency_list'] );
$include_in_woocommerce_product_payment_wallet = sanitize_text_field( $_POST['include_in_woocommerce_product_payment_wallet'] );
$rimplenet_wallet_id = sanitize_text_field( $_POST['rimplenet_wallet_id'] );



$rimplenet_rules_before_wallet_withdrawal = sanitize_text_field( $_POST['rimplenet_rules_before_wallet_withdrawal'] );
$rimplenet_rules_after_wallet_withdrawal = sanitize_text_field( $_POST['rimplenet_rules_after_wallet_withdrawal'] );



// Create wallet on RIMPLENET CPT
$args = array(
    'post_title' => $rimplenet_wallet_name,
    'post_content' => $rimplenet_wallet_desc,
    'post_status' => 'publish',
    'post_type' => "rimplenettransaction",
    ) ;

$wallet_id = wp_insert_post($args);
wp_set_object_terms($wallet_id, $WALLET_CAT_NAME, 'rimplenettransaction_type');
$metas = array(
  'rimplenet_wallet_name' => $rimplenet_wallet_name,
  'rimplenet_wallet_decimal' => $rimplenet_wallet_decimal,
  'rimplenet_wallet_symbol' => $rimplenet_wallet_symbol,
  'rimplenet_wallet_id' => $rimplenet_wallet_id,
  'include_in_withdrawal_form' => $include_in_withdrawal_form,
  'include_in_woocommerce_currency_list' => $include_in_woocommerce_currency_list,
  'include_in_woocommerce_product_payment_wallet' => $include_in_woocommerce_product_payment_wallet,

  'rimplenet_rules_before_wallet_withdrawal' => $rimplenet_rules_before_wallet_withdrawal,
  'rimplenet_rules_after_wallet_withdrawal' => $rimplenet_rules_after_wallet_withdrawal,
);
foreach ($metas as $key => $value) {
  update_post_meta($wallet_id, $key, $value);
}

 echo '<div class="updated">
            <p>Your Wallet have been created successfully</p>
        </div> ';


}


$input_width = 'width:95%';
?>



<div class="rimplenet_admin_div" style="<?php echo $input_width; ?>">


<?php
   $txn_loop = new WP_Query(
           array(  'post_type' => 'rimplenettransaction', 
                   'post_status' => 'publish',
                   'posts_per_page' => -1,
                   'tax_query' => array(
                     array(
                        'taxonomy' => 'rimplenettransaction_type',
                        'field'    => 'name',
                        'terms'    => $WALLET_CAT_NAME,
                ),
             ),)
         );
 if( $txn_loop->have_posts() ){


 


?>
<h2> ACTIVE WALLETS</h2>


<table class="wp-list-table widefat fixed striped posts" >

 <thead>
  <tr>
    <th> Wallet Name </th>
    <th> Description </th>
    <th> Wallet Symbol </th>
    <th> Wallet Decimal </th>
    <th> Wallet Id </th>
    <th> Include Wallet in Withdrawal Form</th>
    <th> Include Wallet in Woocommerce Currency List</th>
    <th> Actions </th>
  </tr>
 </thead>
  
 <tbody>

<?php
  
    while( $txn_loop->have_posts() ){
        $txn_loop->the_post();
        $txn_id = get_the_ID(); 
        $status = get_post_status();
        $title = get_the_title();
        $content = get_the_content();


        $wallet_decimal = get_post_meta($txn_id, 'rimplenet_wallet_decimal', true);
        $wallet_symbol = get_post_meta($txn_id, 'rimplenet_wallet_symbol', true);
        $wallet_id = get_post_meta($txn_id, 'rimplenet_wallet_id', true);
        $include_in_withdrawal_form = get_post_meta($txn_id, 'include_in_withdrawal_form', true);
        $include_in_woocommerce_currency_list = get_post_meta($txn_id, 'include_in_woocommerce_currency_list', true);

       $edit_wallet_link = '<a href="'.get_edit_post_link($txn_id).'" target="_blank">Edit Wallet & Rules</a>';
       //$edit_linked_product_link = ' | <a href="'.get_edit_post_link($linked_woocommerce_product_id).'"  target="_blank">Edit Linked Product</a>'; 
        if(!empty($linked_page_id)){
            $view_wallet_page_link = ' | <a href="'.get_permalink($linked_page_id).'" target="_blank">View Wallet Page</a>' ;
        }
        
        //$view_linked_product_link = ' | <a href="'.get_post_permalink($linked_woocommerce_product_id).'"  target="_blank">View Linked Product</a>';

 ?>
  <tr>
    <td><?php echo $title; ?></td>
    <td><?php echo $content; ?></td>
    <td><?php echo $wallet_symbol; ?></td>
    <td><?php echo $wallet_decimal; ?></td>
    <td> <code class="rimplenet_click_to_copy"><?php echo $wallet_id; ?></code> </td>
    <td><?php echo $include_in_withdrawal_form; ?></td>
    <td><?php echo $include_in_woocommerce_currency_list; ?></td>
    <td> 
      <?php echo $edit_wallet_link; ?> <?php echo $view_wallet_page_link; ?> <?php echo $edit_linked_product_link; ?> <?php echo $view_linked_product_link; ?>
    </td>

    
  </tr>

  <?php

    }

  

  ?>
  
</tbody>

 <tfoot>
  <tr>
    <th> Wallet Name </th>
    <th> Description </th>
    <th> Wallet Symbol </th>
    <th> Wallet Decimal </th>
    <th> Wallet Id </th>
    <th> Include Wallet in Withdrawal Form</th>
    <th> Include Wallet in Woocommerce Currency List</th>
    <th> Actions </th>
  </tr>
  </tfoot>

</table>

<?php

   }
wp_reset_postdata();
?>


<h2>CREATE NEW WALLET</h2>
  <form method="POST">
    <input type="hidden" name="rimplenet_wallet_submitted" value="true" />
    <?php wp_nonce_field( 'rimplenet_wallet_settings_nonce_field', 'rimplenet_wallet_settings_nonce_field' ); ?>

    <table class="form-table">
        <tbody>

            <tr>
                <th><label for="rimplenet_wallet_name"> Wallet Name </label></th>
                <td><input name="rimplenet_wallet_name" id="rimplenet_wallet_name" type="text" value="<?php echo get_option('rimplenet_wallet_name'); ?>" placeholder="e.g United Bunny Wallet" class="regular-text" required style="<?php echo $input_width; ?>" /></td>
            </tr>
            <tr>
                <th><label for="rimplenet_wallet_desc"> Wallet Description </label></th>
                <td>
                  <textarea id="rimplenet_wallet_desc" name="rimplenet_wallet_desc" placeholder="Description here" style="<?php echo $input_width; ?>"></textarea>

                  </td>
            </tr>
            <tr>
                <th><label for="rimplenet_wallet_symbol"> Wallet Symbol </label></th>
                <td><input name="rimplenet_wallet_symbol" id="rimplenet_wallet_symbol" type="text" value="<?php echo get_option('rimplenet_wallet_symbol'); ?>" placeholder="e.g $" class="regular-text" required style="<?php echo $input_width; ?>" /></td>
            </tr>

            <tr>
                <th><label for="rimplenet_wallet_decimal"> Wallet Decimal </label></th>
                <td><input name="rimplenet_wallet_decimal" id="rimplenet_wallet_decimal" type="number" min="1" value="<?php echo get_option('rimplenet_wallet_decimal'); ?>" placeholder="e.g 2"  class="regular-text" required style="<?php echo $input_width; ?>" /></td>
            </tr>
            <tr>
                <th><label for="rimplenet_wallet_id"> Wallet ID </label></th>
                <td><input name="rimplenet_wallet_id" id="rimplenet_wallet_id" type="text" value="<?php echo get_option('rimplenet_wallet_id'); ?>" placeholder="e.g usd" class="regular-text" required style="<?php echo $input_width; ?>" /></td>
            </tr>
            
            <tr>
            <th scope="row">Include in Withdrawal Form</th>
            <td>
              <fieldset>
                  <legend class="screen-reader-text"><span>Include in Withdrawal Form</span></legend>
                  <label><input type="radio" name="include_in_withdrawal_form" value="yes" checked="checked"> 
                  <span class="">Yes Include - (This will show in Withdrawal form.)  </span></label> <br>
                  
                  <label><input type="radio" name="include_in_withdrawal_form" value="no"> 
                  <span class=""> No, Don't Include - (This will not show in Withdrawal form) </span></label> <br>
              
              </fieldset>
            </td>
            
            </tr>
             
            <tr>
            <th scope="row">Include in Woocommerce Currencies</th>
            <td>
              <fieldset>
                  <legend class="screen-reader-text"><span>Include in Woocommerce Currencies</span></legend>
                  <label><input type="radio" name="include_in_woocommerce_currency_list" value="yes" checked="checked"> 
                  <span class="">Yes Include - (This will show in Woocommerce Currency List, be careful as some payment processors may not recognized it.)  </span></label> <br>
                  
                  <label><input type="radio" name="include_in_woocommerce_currency_list" value="no"> 
                  <span class=""> No, Don't Include - (This will not show in Woocommerce Currency List) </span></label> <br>
              
              </fieldset>
            </td>
            
            </tr>
            
              
            <tr>
            <th scope="row">Include as Woocommerce Product Payment Wallet</th>
            <td>
              <fieldset>
                  <legend class="screen-reader-text"><span>Include as Woocommerce Product Payment Wallet</span></legend>
                  <label><input type="radio" name="include_in_woocommerce_product_payment_wallet" value="yes"  checked="checked"> 
                  <span class="">Yes Include - (This will show in Woocommerce Product Payment Wallet)  </span></label> <br>
                  
                  <label><input type="radio" name="include_in_woocommerce_product_payment_wallet" value="no"> 
                  <span class=""> No, Don't Include - (This will not show as Woocommerce Product Payment Wallet) </span></label> <br>
              
              </fieldset>
            </td>
            
            </tr>
            
            
            <tr>
                <td><h2>WALLET RULES</h2> </td>  
            </tr>


            <tr>
                <th><label for="rimplenet_rules_before_wallet_withdrawal"> Rules to Achieve before User Qualifies to Withdraw from this wallet </label></th>
                <td>
                  <textarea name="rimplenet_rules_before_wallet_withdrawal" id="rimplenet_rules_before_wallet_withdrawal" style="<?php echo $input_width; ?>"></textarea>

                  </td>
            </tr>

            <tr>
                <th><label for="rimplenet_rules_after_wallet_withdrawal"> Rules to Apply to User after Withdrawal </label></th>
                <td>
                  <textarea name="rimplenet_rules_after_wallet_withdrawal" id="rimplenet_rules_after_wallet_withdrawal" style="<?php echo $input_width; ?>"></textarea>

                </td>
            </tr>
            
        </tbody>
    </table>

    <p class="submit">
        <input type="submit" name="submit" id="submit" class="button button-primary" value="CREATE WALLET">
    </p>
  </form>
</div>