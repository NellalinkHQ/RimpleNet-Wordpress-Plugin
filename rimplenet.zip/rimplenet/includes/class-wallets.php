<?php



class Rimplenet_Wallets {
 
   
  
public function __construct() {
    
 add_action('add_decode_rimplenet_rules', array($this,'rimplenet_rules_add_to_mature_wallet'), 25, 4 );
 add_action('add_decode_rimplenet_rules', array($this,'rimplenet_rules_add_to_immature_wallet'), 25, 4 );
 add_shortcode('rimplenet-wallet', array($this, 'ShortcodeDesignWallet'));
 add_shortcode('rimplenet-user-to-user-wallet-transfer-form', array($this, 'UserToUserWalletTransferForm'));
 
 
 /**
 * Custom currency and currency symbol
 */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))){

 add_action('admin_init',  array($this,'update_rimplenet_woocommerce_wallet_and_currency'));
 add_filter('woocommerce_currencies', array($this,'add_rimplenet_currency' ));
//add_filter('woocommerce_currency_symbol', array($this,'add_rimplenet_currency_symbol', 10, 2));
}

 add_action( 'show_user_profile', array($this,'rimplenet_extra_user_profile_fields' ));
 add_action( 'edit_user_profile', array($this,'rimplenet_extra_user_profile_fields' ));
 add_action( 'personal_options_update', array($this,'save_rimplenet_extra_user_profile_fields' ));
 add_action( 'edit_user_profile_update', array($this,'save_rimplenet_extra_user_profile_fields' ));


}


function rimplenet_rules_add_to_mature_wallet($rule,$user, $obj_id='', $args='')
{
 
 $amount  = trim($args[0]);
 $wallet_id  = trim($args[1]);
 //$notification_mode  = 'silent';
 if(!is_numeric($amount)){
    $status = 'RIMPLENET_RULES_ERROR_AMOUNT_NOT_NUMERIC_'.$amount;
 }
 elseif(strpos($rule, "rimplenet_rules_add_to_mature_wallet") !== false AND is_numeric($amount)){
     
    $this->add_user_mature_funds_to_wallet($user->ID,$amount, $wallet_id, 'Txn Returns');
   $status = rimplenetRulesExecuted($rule,$user,$obj_id,$args);
 }
 else{
     
    $status = 'RIMPLENET_UNKNOWN_ERROR';
 }
 
 return $status;
       
}



function rimplenet_rules_add_to_immature_wallet($rule,$user, $obj_id='', $args='')
{
 
 $amount  = trim($args[0]);
 $wallet_id  = trim($args[1]);
 //$notification_mode  = 'silent';
 if(!is_numeric($amount)){
    $status = 'RIMPLENET_RULES_ERROR_AMOUNT_NOT_NUMERIC_'.$amount;
 }
 elseif(strpos($rule, "rimplenet_rules_add_to_immature_wallet") !== false AND is_numeric($amount)){
     
    $this->add_user_immature_funds_to_wallet($user->ID,$amount, $wallet_id, 'Txn Returns');
    $status = rimplenetRulesExecuted($rule,$user,$obj_id,$args);
 } 
 else{
     
    $status = 'RIMPLENET_UNKNOWN_ERROR';
 }
 
 return $status;
 
}

public function ShortcodeDesignWallet($atts){
    
      ob_start();

      include plugin_dir_path( dirname( __FILE__ ) ) . 'public/layouts/design-wallet-from-shortcode.php';
       
      $output = ob_get_clean();

      return $output;
    

}
   
public function UserToUserWalletTransferForm($atts) {
          

      ob_start();

      include plugin_dir_path( dirname( __FILE__ ) ) . 'public/layouts/design-transfer-wallet-to-wallet.php';
       
      $output = ob_get_clean();

      return $output;
    


}


function withdraw_wallet_bal($user_id, $amount_to_withdraw, $wallet_id, $address_to, $note=''){
       
        
        $min_wdr_amt= 0;
    	$user_wdr_bal = $this->get_withdrawable_wallet_bal($user_id, $wallet_id);
    	$user_non_wdr_bal = $this->get_nonwithdrawable_wallet_bal($user_id, $wallet_id);
    	
    	$walllets = $this->getWallets();
        $dec = $walllets[$wallet_id]['decimal'];
        $symbol = $walllets[$wallet_id]['symbol'];
        $name = $walllets[$wallet_id]['name'];
          
          $balance = $symbol.number_format($balance,$dec);
    	
        if (empty($amount_to_withdraw) OR empty($wallet_id) ) {
    		$wdr_info = 'One or more compulsory field is empty';
    	  }
    	 elseif ($amount_to_withdraw>$user_wdr_bal) {
    		$wdr_info = 'Amount to withdraw - <strong>['.$symbol.number_format($amount_to_withdraw,$dec).']</strong> is larger than the amount in your mature wallet, input amount not more than the balance in your <strong>( '.$name.' mature wallet - ['.$symbol.number_format($user_wdr_bal,$dec).'] ),</strong> the balance in your <strong>( '.$name.' immature wallet  - ['. $symbol.number_format($user_non_wdr_bal,$dec).'] )</strong>  cannot be withdrawn until maturity';
    	  }
    
    	elseif ($amount_to_withdraw<$min_wdr_amt) {
    		$wdr_info = 'Requested amount ['.$amount_to_withdraw.'] is below minimum withdrawal amount, input amount not less than '.$min_wdr_amt;
    	}
    	else{
    		
    			  
        
         $amount_to_withdraw = $amount_to_withdraw * -1;
         $txn_wdr_id = $this->add_user_mature_funds_to_wallet($user_id,$amount_to_withdraw, $wallet_id, $note);
    
         if (is_int($txn_wdr_id)) {
           $modified_title = 'WITHDRAWAL ~ '.get_the_title( $txn_wdr_id);
           $args = 
              array(
              'ID'    =>  $txn_wdr_id,
              'post_title'   => $modified_title,
              'post_status'   =>  'pending',
               'meta_input' => array(
                'withdrawal_address_to'=>$address_to,
                'note'=>$note,
                )
              );
              
    
             wp_set_object_terms($txn_wdr_id, 'WITHDRAWAL', 'rimplenettransaction_type', true);
             wp_update_post($args);
     
             $wdr_info = $txn_wdr_id;
             
          }
    	}
     wp_reset_postdata();
    return $wdr_info;

}

function transfer_wallet_bal($user_id, $amount_to_transfer, $wallet_id, $transfer_to_user, $note=''){
    
        $current_user = get_user_by('ID', $user_id);
	    $current_user_id  = $current_user ->ID;
	    
        $user_transfer_to = get_user_by('login', $transfer_to_user);
	    $transfer_to_user_id  = $user_transfer_to->ID;
	    
		$min_transfer_amt = 0;
    	$user_transfer_bal = $this->get_withdrawable_wallet_bal($user_id, $wallet_id);
    	$user_non_transfer_bal = $this->get_nonwithdrawable_wallet_bal($user_id, $wallet_id);
    	
    	$walllets = $this->getWallets();
        $dec = $walllets[$wallet_id]['decimal'];
        $symbol = $walllets[$wallet_id]['symbol'];
        $name = $walllets[$wallet_id]['name'];
        $balance = $symbol.number_format($balance,$dec);
    	
    	
        if (empty($user_id) OR empty($amount_to_transfer) OR empty($wallet_id)  OR empty($transfer_to_user) ) {
    		$transfer_info = 'One or more compulsory field is empty';
    	  }
    	 elseif ($amount_to_transfer>$user_transfer_bal) {
    		$transfer_info = 'Amount to transfer - <strong>['.$symbol.number_format($amount_to_transfer,$dec).']</strong> is larger than the amount in your mature wallet, input amount not more than the balance in your <strong>( '.$name.' mature wallet - ['.$symbol.number_format($user_transfer_bal,$dec).'] ),</strong> the balance in your <strong>( '.$name.' immature wallet  - ['. $symbol.number_format($user_non_transfer_bal,$dec).'] )</strong>  cannot be transferred until maturity';
    	 }
    	elseif ($amount_to_transfer<$min_transfer_amt) {
    		$transfer_info = 'Requested amount ['.$amount_to_transfer.'] is below minimum transfer amount, input amount not less than '.$min_transfer_amt;
    	}
    	elseif (!username_exists($user_transfer_to->user_login)) {
			$transfer_info = 'User with the username <b>['.$transfer_to_user.']</b> does not exist, please crosscheck the username';
		}
    	else{ // all is good, make transfer
    		
    	  //transfer funds to user
    	  
          $amount_to_transfer_to_user = apply_filters('rimplenet_amount_to_transfer', $amount_to_transfer, $wallet_id, $transfer_to_user_id);
          $txn_transfer_id1 = $this->add_user_mature_funds_to_wallet($transfer_to_user_id,$amount_to_transfer_to_user, $wallet_id,$note);
         
         $transfer_info = $txn_transfer_id1; 
         if (is_int($txn_transfer_id1)) {
            
          $modified_title = 'TRANSFER ~ '.get_the_title( $txn_transfer_id1);
           $args = 
              array(
              'ID'    =>  $txn_transfer_id1, 
              'post_title'   => $modified_title,
              'post_status'   =>  'publish',
               'meta_input' => array(
                'transfer_address_from'=>$user_id,
                'note'=>__("TRANSFER from $current_user->user_login $note"),
                )
              );
             wp_set_object_terms($txn_transfer_id1, 'TRANSFER', 'rimplenettransaction_type', true);
             wp_set_object_terms($txn_transfer_id1, 'INTERNAL TRANSFER', 'rimplenettransaction_type', true);
             wp_update_post($args);

          //debit from user making the transfer
         
          $amount_to_debit_in_transfer = $amount_to_transfer * -1;
          $txn_transfer_id2 = $this->add_user_mature_funds_to_wallet($user_id, $amount_to_debit_in_transfer, $wallet_id, $note);
         }
         
         
         if (is_int($txn_transfer_id2)) {
            

          $modified_title = 'TRANSFER ~ '.get_the_title($txn_transfer_id2);
           $args = 
              array(
              'ID'    =>  $txn_transfer_id2, 
              'post_title'   => $modified_title,
              'post_status'   =>  'publish',
               'meta_input' => array(
                'transfer_address_to'=>$transfer_to_user_id,
                'note'=>__("TRANSFER to $user_transfer_to->user_login $note"),
                )
              );
             wp_set_object_terms($txn_transfer_id2, 'TRANSFER', 'rimplenettransaction_type', true);
             wp_set_object_terms($txn_transfer_id2, 'INTERNAL TRANSFER', 'rimplenettransaction_type', true);
             wp_update_post($args);
             
             $transfer_info = $txn_transfer_id2;
          }
        }
        
    update_post_meta($txn_transfer_id1, "alt_transfer_id",$txn_transfer_id2);
    update_post_meta($txn_transfer_id2, "alt_transfer_id",$txn_transfer_id1);


     wp_reset_postdata();
     return $transfer_info;

}


function add_user_immature_funds_to_wallet($user_id,$amount_to_add,$wallet_id,$note='',$tags=[]){

   $key = 'user_nonwithdrawable_bal_'.strtolower($wallet_id);
   $user_balance = get_user_meta($user_id, $key, true);
   

   if (!is_numeric($user_balance) and !is_int($user_balance)){
    $user_balance = 0;
   }
   
    $bal_before = $user_balance;
    $user_balance_total = $this->get_total_wallet_bal($user_id,$wallet_id);

    $new_balance  = $user_balance + $amount_to_add; 
    $new_balance  = $new_balance;
   
    update_user_meta($user_id, $key, $new_balance);
    

    if ($amount_to_add>0) {
     $tnx_type = 'CREDIT';
   }
   else{
     $tnx_type = 'DEBIT';
     $amount_to_add = $amount_to_add * -1;
    }

    $txn_add_bal_id = $this->record_Txn($user_id,$amount_to_add, $wallet_id, $tnx_type ,'publish');

    if (!empty($note)) {
        add_post_meta($txn_add_bal_id, 'note', $note);
      }
    update_post_meta($txn_add_bal_id, 'balance_before', $bal_before);
    update_post_meta($txn_add_bal_id, 'balance_after', $new_balance);
    
    update_post_meta($txn_add_bal_id, 'total_balance_before', $user_balance_total);
    update_post_meta($txn_add_bal_id, 'total_balance_after', $this->get_total_wallet_bal($user_id,$wallet_id));
    
    update_post_meta($txn_add_bal_id, 'funds_type', $key);


  return $txn_add_bal_id;
}


function add_user_mature_funds_to_wallet($user_id,$amount_to_add,$wallet_id, $note='',$tags=[]){


   $key = 'user_withdrawable_bal_'.strtolower($wallet_id);
   $user_balance = get_user_meta($user_id, $key, true);

   if (!is_numeric($user_balance) and !is_int($user_balance)){
    $user_balance = 0;
   }

    $bal_before = $user_balance;
    $user_balance_total = $this->get_total_wallet_bal($user_id,$wallet_id);

    $new_balance  = $user_balance + $amount_to_add; 
    $new_balance  = $new_balance;
   
    update_user_meta($user_id, $key, $new_balance);

    if ($amount_to_add>0) {
     $tnx_type = 'CREDIT';
    }
   else{
     $tnx_type = 'DEBIT';
     $amount_to_add = $amount_to_add * -1;
    }

    $txn_add_bal_id = $this->record_Txn($user_id,$amount_to_add, $wallet_id, $tnx_type ,'publish');

    if (!empty($note)) {
        add_post_meta($txn_add_bal_id, 'note', $note);
      }
    update_post_meta($txn_add_bal_id, 'balance_before', $bal_before);
    update_post_meta($txn_add_bal_id, 'balance_after', $new_balance);
    
    update_post_meta($txn_add_bal_id, 'total_balance_before', $user_balance_total);
    update_post_meta($txn_add_bal_id, 'total_balance_after', $this->get_total_wallet_bal($user_id,$wallet_id));
    
    update_post_meta($txn_add_bal_id, 'funds_type', $key);


  return $txn_add_bal_id;

}


function get_nonwithdrawable_wallet_bal($user_id,$wallet_id){

  $key = 'user_nonwithdrawable_bal_'.strtolower($wallet_id);
 
  $user_balance = get_user_meta($user_id, $key, true);
  if (empty($user_balance)) {
      $user_balance = 0;
  }
  
  //$balance = number_format($user_balance,2);
  $balance = $user_balance;

  return $balance;
}

function get_withdrawable_wallet_bal($user_id,$wallet_id){

  $key = 'user_withdrawable_bal_'.strtolower($wallet_id);
 
  $user_balance = get_user_meta($user_id, $key, true);
  if (empty($user_balance)) {
      $user_balance = 0;
  }
  
  //$balance = number_format($user_balance,2);
  $balance = $user_balance;

  return $balance;

}

function get_total_wallet_bal($user_id,$wallet_id){

  
  $balance = $this->get_withdrawable_wallet_bal($user_id, $wallet_id) + $this-> get_nonwithdrawable_wallet_bal($user_id, $wallet_id);

  $walllets = $this->getWallets();
  $dec = $walllets[$wallet_id]['decimal'];
  
  //$balance = number_format($balance,$dec);

  return $balance;

}

function get_total_wallet_bal_disp_formatted($user_id,$wallet_id){

  
  $balance = $this->get_withdrawable_wallet_bal($user_id, $wallet_id) + $this-> get_nonwithdrawable_wallet_bal($user_id, $wallet_id);

  $walllets = $this->getWallets();
  $dec = $walllets[$wallet_id]['decimal'];
  $symbol = $walllets[$wallet_id]['symbol'];
  
  $balance = $symbol.number_format($balance,$dec);

  return $balance;

}


function record_Txn($user_id, $amount, $wallet_id, $tnx_type ,$status='pending'){

        $user_info = get_user_by('ID', $user_id);
        $walllets = $this->getWallets();
        $decimal = $walllets[$wallet_id]['decimal'];
        $amount_formatted = number_format($amount,$decimal);
        $wallet_symbol = $walllets[$wallet_id]['symbol'];
        $wallet_name = $walllets[$wallet_id]['name'];

        $post_title = 'TRANSACTION by '.$user_info->user_login .', Type: '.$tnx_type.', Wallet Info: '.$wallet_symbol.''.$amount_formatted.' '.$wallet_name.'  on '.date("l jS \of F Y @ h:i:s A");

         $post_content = 'Amount:'.$amount;

         $new_txn_args = array(
              'post_author'=> $user_info->ID,
              'post_type' => 'rimplenettransaction',
              'post_title'    => wp_strip_all_tags($post_title),
              'post_content'  => $post_content,
              'post_status'   => $status,
              'meta_input' => array(
                'amount'=>$amount,
                'currency'=>strtolower($wallet_id),
                'txn_type'=>$tnx_type
                ),
              );
         
               
       $new_txn = wp_insert_post($new_txn_args);


       if ($tnx_type=='BUY' or $tnx_type=='SELL') {
           $amount_usd = $amount;
           update_post_meta($new_txn, 'amount_usd', $amount_usd);
           
           $amount_coin = $amount;
           update_post_meta($new_txn, 'amount_coin', $amount_coin);

          $rate_1usd_to_coin = get_option('rate_1btc_to_usd_rate',9000);
          $amount_btc = $amount_usd/$rate_1usd_to_coin;
          update_post_meta($new_txn, 'amount_btc', $amount_btc);
         
       }

       if (is_int($new_txn)) {
         wp_set_object_terms($new_txn, $tnx_type, 'rimplenettransaction_type', true);

         return $new_txn;
       }

       wp_reset_postdata();


}



function rimplenet_extra_user_profile_fields( $user ) { ?>
    <h3><?php _e("RIMPLENET Wallet Balance", "bvnb"); ?></h3>

    <table class="form-table">
    <?php
     $all_wallets = $this->getWallets();
     
     foreach ($all_wallets as $wallet_id=> $single_wallet) {
      $key_nonwithdrawable = 'user_nonwithdrawable_bal_'.$single_wallet['id'];
      $name_nonwithdrawable = $single_wallet['name'].' ~ ('.$single_wallet['symbol'].') - NON WITHDRAWABLE';

      $key_withdrawable = 'user_withdrawable_bal_'.$single_wallet['id'];
      $name_withdrawable = $single_wallet['name'].' ~ ('.$single_wallet['symbol'].') - WITHDRAWABLE';

      ?>
      <tr><td colspan="3"><hr></td></tr>
       <tr>
        <th><label for="<?php echo $key_nonwithdrawable; ?>"><?php _e($name_nonwithdrawable); ?></label></th>
        <td>
            <input type="text" name="<?php echo $key_nonwithdrawable; ?>" id="<?php echo $key_nonwithdrawable; ?>" value="<?php echo esc_attr( get_the_author_meta( $key_nonwithdrawable, $user->ID ) ); ?>" class="regular-text" /><br />
            <span class="description"><?php _e($name_nonwithdrawable); ?></span>
        </td>
       </tr>

       <tr>
        <th><label for="<?php echo $key_withdrawable; ?>"><?php _e($name_withdrawable); ?></label></th>
        <td>
            <input type="text" name="<?php echo $key_withdrawable; ?>" id="<?php echo $key_withdrawable; ?>" value="<?php echo esc_attr( get_the_author_meta( $key_withdrawable, $user->ID ) ); ?>" class="regular-text" /><br />
            <span class="description"><?php _e($name_withdrawable); ?></span>
        </td>
       </tr>


    <?php
     }
    ?>
    <tr><td colspan="3"><hr></td></tr>
   </table>
<?php }


function save_rimplenet_extra_user_profile_fields( $user_id ) {
    if ( !current_user_can( 'edit_user', $user_id ) ) { 
        return false; 
    }
   
   $all_wallets = $this->getWallets();
     
     foreach ($all_wallets as $wallet_id=> $single_wallet) {
      $key_non_withdrawable = 'user_nonwithdrawable_bal_'.$single_wallet['id'];

      $key_withdrawable = 'user_withdrawable_bal_'.$single_wallet['id'];

      if (isset($_POST[$key_non_withdrawable])) {
        update_user_meta( $user_id, $key_non_withdrawable , sanitize_text_field($_POST[$key_non_withdrawable] )); 
      }

      if (isset($_POST[$key_withdrawable])) {
        update_user_meta( $user_id, $key_withdrawable , sanitize_text_field($_POST[$key_withdrawable] )); 
      }


    }

  


  }


function add_rimplenet_currency( $currencies ) {
     $include_only = array('default','db');
     $all_wallets = $this->getWallets($include_only);
     
     
     foreach($all_wallets as $wallet_id => $wallet){
         
         $include_in_woocommerce_currency_list = $wallet['include_in_woocommerce_currency_list'];
         
        if($include_in_woocommerce_currency_list =='yes'){
         $rimplenet_wallet_id = 'rimplenet_'.$wallet_id;
         $rimplenet_wallet_name = $wallet['name'];
         $rimplenet_wallet_name = $wallet['name'];
         $currencies[$rimplenet_wallet_id] = __( $rimplenet_wallet_name, 'woocommerce' ); 
        }
     }
     
    //$currencies['ABC'] = __( 'ABC Currency name', 'woocommerce' );
    
     return $currencies;
}


function add_rimplenet_currency_symbol( $currency_symbol, $currency ) {
    
     switch( $currency ) {
          case 'ABC': $currency_symbol = '$'; break;
     }
     
     return $currency_symbol;
}

function update_rimplenet_woocommerce_wallet_and_currency() {
    
      $woo_cur_symbol = get_woocommerce_currency_symbol();
      $woo_cur = get_woocommerce_currency();
    
      $all_woo_cur_array = get_woocommerce_currencies();
      $woo_cur_name = $all_woo_cur_array[$woo_cur];
      $woo_cur_name_disp = $woo_cur_name.' ('.$woo_cur.')';
    
      $rimplenet_woocommerce_wallet_and_currency = array( 
        "id" => "woocommerce_base_cur",  
        "name" => $woo_cur_name_disp,  
        "symbol" => $woo_cur_symbol,  
        "value_1_to_base_cur" => 0.01, 
        "value_1_to_usd" => 1, 
        "value_1_to_btc" => 0.01, 
        "decimal" => 2, 
        "include_in_withdrawal_form" => 'yes',
        "include_in_woocommerce_currency_list" => 'no',
        "action" => array( 
          "deposit" => "yes",  
          "withdraw" => "yes", 
      ) 
     ); 
    
    update_option( 'rimplenet_woocommerce_wallet_and_currency', $rimplenet_woocommerce_wallet_and_currency );

    
}

function getWallets($include_only='' ){ //$exclude can be default, woocommerce, or db
  if(empty($include_only)){$include_only = array('default','woocommerce','db');}

      $activated_wallets = array();
      $wallet_type = array('mature','immature'); 
  
      
    if(in_array('default', $include_only)){
      
    $activated_wallets['rimplenetcoin'] = array( 
      "id" => "rimplenetcoin",  
      "name" => "RIMPLENET Coin",
      "symbol" => "RMPNCOIN",  
      "value_1_to_base_cur" => 0.01, 
      "value_1_to_usd" => 1, 
      "value_1_to_btc" => 0.01, 
      "decimal" => 0, 
      "include_in_withdrawal_form" => 'yes',
      "include_in_woocommerce_currency_list" => 'no',
      "action" => array( 
          "deposit" => "yes",  
          "withdraw" => "yes", 
      ) 
    ); 
  
 }
 
 if(in_array('woocommerce', $include_only) AND in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))){
          //For Woocommerce
          $activated_wallets['woocommerce_base_cur']  = apply_filters( 'rimplenet_filter_woocommerce_base_cur', get_option('rimplenet_woocommerce_wallet_and_currency') );
      }
  
     /*
     $activated_wallets['btc'] = array( 
          "id" => "btc",  
          "name" => "Bitcoin", 
          "symbol" => "BTC", 
          "value_1_to_base_cur" => 0.01, 
          "value_1_to_usd" => 0.01, 
          "value_1_to_btc" => 0.01, 
          "decimal" => 8, 
          "include_in_woocommerce_currency_list" => 'no',
          "action" => array( 
              "deposit" => "yes",  
              "withdraw" => "yes", 
          ) 
      ); 
      
      */

 
     
  if(in_array('db', $include_only)){
   //Add Wallets saved in database
   $WALLET_CAT_NAME = 'RIMPLENET WALLETS';
   $txn_loop = new WP_Query(
           array(  'post_type' => 'rimplenettransaction', 
                   'post_status' => 'publish',
                   'posts_per_page' => -1,
                   'tax_query' => array(
                     array(
                        'taxonomy' => 'rimplenettransaction_type',
                        'field'    => 'name',
                        'terms'    => $WALLET_CAT_NAME,
                ),
             ),)
         );
   if( $txn_loop->have_posts() ){
    while( $txn_loop->have_posts() ){
        $txn_loop->the_post();
        $txn_id = get_the_ID(); 
        $status = get_post_status();
        $wallet_name = get_the_title();
        $wallet_desc  = get_the_content();
        
        $wallet_decimal = get_post_meta($txn_id, 'rimplenet_wallet_decimal', true);
        $wallet_symbol = get_post_meta($txn_id, 'rimplenet_wallet_symbol', true);
        $wallet_id = get_post_meta($txn_id, 'rimplenet_wallet_id', true);
        $include_in_withdrawal_form = get_post_meta($txn_id, 'include_in_withdrawal_form', true);
        $include_in_woocommerce_currency_list = get_post_meta($txn_id, 'include_in_woocommerce_currency_list', true);
        
        $activated_wallets[$wallet_id] = array( 
              "id" => $wallet_id,  
              "name" => $wallet_name,
              "symbol" => $wallet_symbol,  
              "value_1_to_base_cur" => 0.01, 
              "value_1_to_usd" => 1, 
              "value_1_to_btc" => 0.01, 
              "decimal" => $wallet_decimal, 
              "include_in_withdrawal_form" => 'yes',
              "include_in_woocommerce_currency_list" => $include_in_woocommerce_currency_list,
              "action" => array( 
                  "deposit" => "yes",  
                  "withdraw" => "yes",
                  
              ) 
          ); 
        }
        
    }
    
    wp_reset_postdata();
  }


 return $activated_wallets;
  
  
}



}



$Rimplenet_Wallets = new Rimplenet_Wallets();

function RimplenetGetWallets($include_only=''){
    $wallet_obj = new Rimplenet_Wallets();
    return $wallet_obj->getWallets($include_only);
}

function rimplenet_form_field( $key, $args, $value = null ) {
    $defaults = array(
        'type'              => 'text',
        'label'             => '',
        'description'       => '',
        'placeholder'       => '',
        'maxlength'         => false,
        'required'          => false,
        'autocomplete'      => false,
        'id'                => $key,
        'class'             => array(),
        'label_class'       => array(),
        'input_class'       => array(),
        'return'            => false,
        'options'           => array(),
        'custom_attributes' => array(),
        'validate'          => array(),
        'default'           => '',
        'autofocus'         => '',
        'priority'          => '',
    );

    $args = wp_parse_args( $args, $defaults );
    $args = apply_filters( 'rimplenet_form_field_args', $args, $key, $value );

    if ( $args['required'] ) {
        $args['class'][] = 'validate-required';
        $required        = '&nbsp;<abbr class="required" title="' . esc_attr__( 'required', 'rimplenet' ) . '">*</abbr>';
    } else {
        $required = '&nbsp;<span class="optional">(' . esc_html__( 'optional', 'rimplenet' ) . ')</span>';
    }

    if ( is_string( $args['label_class'] ) ) {
        $args['label_class'] = array( $args['label_class'] );
    }

    if ( is_null( $value ) ) {
        $value = $args['default'];
    }

    // Custom attribute handling.
    $custom_attributes         = array();
    $args['custom_attributes'] = array_filter( (array) $args['custom_attributes'], 'strlen' );

    if ( $args['maxlength'] ) {
        $args['custom_attributes']['maxlength'] = absint( $args['maxlength'] );
    }

    if ( ! empty( $args['autocomplete'] ) ) {
        $args['custom_attributes']['autocomplete'] = $args['autocomplete'];
    }

    if ( true === $args['autofocus'] ) {
        $args['custom_attributes']['autofocus'] = 'autofocus';
    }

    if ( $args['description'] ) {
        $args['custom_attributes']['aria-describedby'] = $args['id'] . '-description';
    }

    if ( ! empty( $args['custom_attributes'] ) && is_array( $args['custom_attributes'] ) ) {
        foreach ( $args['custom_attributes'] as $attribute => $attribute_value ) {
            $custom_attributes[] = esc_attr( $attribute ) . '="' . esc_attr( $attribute_value ) . '"';
        }
    }

    if ( ! empty( $args['validate'] ) ) {
        foreach ( $args['validate'] as $validate ) {
            $args['class'][] = 'validate-' . $validate;
        }
    }

    $field           = '';
    $label_id        = $args['id'];
    $sort            = $args['priority'] ? $args['priority'] : '';
    $field_container = '<p class="form-row %1$s" id="%2$s" data-priority="' . esc_attr( $sort ) . '">%3$s</p>';

    switch ( $args['type'] ) {
        
        case 'textarea':
            $field .= '<textarea name="' . esc_attr( $key ) . '" class="input-text ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" id="' . esc_attr( $args['id'] ) . '" placeholder="' . esc_attr( $args['placeholder'] ) . '" ' . ( empty( $args['custom_attributes']['rows'] ) ? ' rows="2"' : '' ) . ( empty( $args['custom_attributes']['cols'] ) ? ' cols="5"' : '' ) . implode( ' ', $custom_attributes ) . '>' . esc_textarea( $value ) . '</textarea>';

            break;
        case 'checkbox':
            $field = '<label class="checkbox ' . implode( ' ', $args['label_class'] ) . '" ' . implode( ' ', $custom_attributes ) . '>
                    <input type="' . esc_attr( $args['type'] ) . '" class="input-checkbox ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="1" ' . checked( $value, 1, false ) . ' /> ' . $args['label'] . $required . '</label>';

            break;
        case 'text':
        case 'password':
        case 'datetime':
        case 'datetime-local':
        case 'date':
        case 'month':
        case 'time':
        case 'week':
        case 'number':
        case 'email':
        case 'url':
        case 'tel':
            $field .= '<input type="' . esc_attr( $args['type'] ) . '" class="input-text ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" placeholder="' . esc_attr( $args['placeholder'] ) . '"  value="' . esc_attr( $value ) . '" ' . implode( ' ', $custom_attributes ) . ' />';

            break;
        case 'select':
            $field   = '';
            $options = '';

            if ( ! empty( $args['options'] ) ) {
                foreach ( $args['options'] as $option_key => $option_text ) {
                    if ( '' === $option_key ) {
                        // If we have a blank option, select2 needs a placeholder.
                        if ( empty( $args['placeholder'] ) ) {
                            $args['placeholder'] = $option_text ? $option_text : __( 'Choose an option', 'rimplenet' );
                        }
                        $custom_attributes[] = 'data-allow_clear="true"';
                    }
                    $options .= '<option value="' . esc_attr( $option_key ) . '" ' . selected( $value, $option_key, false ) . '>' . esc_attr( $option_text ) . '</option>';
                }

                $field .= '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="select ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . implode( ' ', $custom_attributes ) . ' data-placeholder="' . esc_attr( $args['placeholder'] ) . '">
                        ' . $options . '
                    </select>';
            }

            break;
        case 'radio':
            $label_id .= '_' . current( array_keys( $args['options'] ) );

            if ( ! empty( $args['options'] ) ) {
                foreach ( $args['options'] as $option_key => $option_text ) {
                    $field .= '<input type="radio" class="input-radio ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" value="' . esc_attr( $option_key ) . '" name="' . esc_attr( $key ) . '" ' . implode( ' ', $custom_attributes ) . ' id="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '"' . checked( $value, $option_key, false ) . ' />';
                    $field .= '<label for="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '" class="radio ' . implode( ' ', $args['label_class'] ) . '">' . $option_text . '</label>';
                }
            }

            break;
    }

    if ( ! empty( $field ) ) {
        $field_html = '';

        if ( $args['label'] && 'checkbox' !== $args['type'] ) {
            $field_html .= '<label for="' . esc_attr( $label_id ) . '" class="' . esc_attr( implode( ' ', $args['label_class'] ) ) . '">' . $args['label'] . $required . '</label>';
        }

        $field_html .= '<span class="rimplenet-input-wrapper">' . $field;

        if ( $args['description'] ) {
            $field_html .= '<span class="description" id="' . esc_attr( $args['id'] ) . '-description" aria-hidden="true">' . wp_kses_post( $args['description'] ) . '</span>';
        }

        $field_html .= '</span>';

        $container_class = esc_attr( implode( ' ', $args['class'] ) );
        $container_id    = esc_attr( $args['id'] ) . '_field';
        $field           = sprintf( $field_container, $container_class, $container_id, $field_html );
    }

    /**
     * Filter by type.
     */
    $field = apply_filters( 'rimplenet_form_field_' . $args['type'], $field, $key, $args, $value );

    /**
     * General filter on form fields.
     *
     * @since 3.4.0
     */
    $field = apply_filters( 'rimplenet_form_field', $field, $key, $args, $value );

    if ( $args['return'] ) {
        return $field;
    } else {
        echo $field; // WPCS: XSS ok.
    }
}
